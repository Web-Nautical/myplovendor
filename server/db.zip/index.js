
const express = require('express');
const cors = require('cors');
require("dotenv").config({ path: "./config.env" });
const connectDB = require("./db/conn");
const port = process.env.PORT || 8000;
const bodyParser = require('body-parser');
const vendorRoutes = require('./routes/vendors');
const gigsRoutes = require('./routes/gigs');
const paymentRoutes = require('./routes/payments');
const app = express();
const path = require('path');

//middlewares
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(cors());
app.use(express.static(path.join(__dirname + "/public")))

app.use('/uploads', express.static('uploads'));

//routes middleware
app.use('/vendor', vendorRoutes);
app.use('/gigs', gigsRoutes);
app.use('/payment', paymentRoutes);

// app.use('/', express.static('images'))

// Connect to MongoDB
connectDB();

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});