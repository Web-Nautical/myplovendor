const vendorcatModel = require("../model/vendorCategory");
const Vendor = require("../model/vendor");
const gigsModel = require("../model/gigs");

const bcrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");

const express = require("express");
const router = express.Router();
const multer = require('multer');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'images')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
  });

const upload = multer({ storage: storage });

router.post('/login', async (req, res) => {
  try {
    const { vendoremail, vendorpassword } = req.body;
    const vendor = await Vendor.findOne({ vendoremail });

    bcrypt.compare(vendorpassword, vendor.vendorpassword, async (err, passwordMatch) => {
      if (err) {
        console.error(err);
        return res.status(200).json({ status: 'error', message: 'An error occurred' });
      }

      if (passwordMatch) {
        const token = jwt.sign({ vendoremail }, process.env.JWT_SECRET, {
          expiresIn: process.env.JWT_EXPIRES_IN,
        });
        if (vendor) {
          vendor.vendorauthtoken = token;
          await vendor.save();
        }
        return res.json({ status: 'success', message: 'Password is a match', Authtoken: token });
      } else {
        return res.status(200).json({ status: 'error', message: 'Invalid credentials' });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});

router.post('/getvendordata', async (req, res) => {
  try {
    const authHeader = req.headers.xauthorization;
    console.log(authHeader);
    if (authHeader) {
    const Authtoken = authHeader.split(' ')[1];
    const vendor = await Vendor.findOne({ vendorauthtoken:Authtoken });
    if (vendor) {
      return res.json({ status: 'success',  vendorData: vendor });
    }else{
      res.status(200).json({ status: 'error', message: 'Token Expired' });  
    }
  }else{
    res.status(200).json({ status: 'error', message: 'Token Expired' }); 
  }
  } catch (error) {
    console.error(error);
    res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});

router.post('/updatevendordata', async (req, res) => {
  try {
    const authHeader = req.headers.xauthorization;
    console.log(authHeader);
    if (authHeader) {
    const Authtoken = authHeader.split(' ')[1];
    const { vendorname, vendoraddress, vendormobile, vendordescription, vendorstate, vendorcountry } = req.body;

    const vendor = await Vendor.findOne({ vendorauthtoken:Authtoken });
    if (vendor) {
      vendor.vendorname = vendorname;
      vendor.vendoraddress = vendoraddress;
      vendor.vendormobile = vendormobile;
      vendor.vendordescription = vendordescription;
      vendor.vendorstate = vendorstate;
      vendor.vendorcountry = vendorcountry;
      await vendor.save();
      return res.json({ status: 'success',  vendorData: vendor });
    }else{
      res.status(200).json({ status: 'error', message: 'Token Expired' });  
    }
  }else{
    res.status(200).json({ status: 'error', message: 'Token Expired' }); 
  }
  } catch (error) {
    console.error(error);
    res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});

router.post('/vendordashboarddata', async (req, res) => {
  try {
    const authHeader = req.headers.xauthorization;
    if (authHeader) {
    const Authtoken = authHeader.split(' ')[1];
    const vendor = await Vendor.findOne({ vendorauthtoken:Authtoken });
    if (vendor) {
      const gigscount = await gigsModel.countDocuments({ vendorid: vendor._id });
      const messagescount = 0;
      const paymentreceived = 0;
      return res.json({ status: 'success',  gigsCount: gigscount, messagescount:messagescount, paymentreceived:paymentreceived });
    }else{
      res.status(200).json({ status: 'error', message: 'Token Expired' });  
    }
  }else{
    res.status(200).json({ status: 'error', message: 'Token Expired' }); 
  }
  } catch (error) {
    console.error(error);
    res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});

module.exports = router;