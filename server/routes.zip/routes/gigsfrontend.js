const gigsModel = require("../model/gigs");
const GigsImage = require("../model/gigimages");
const vendorcatModel = require("../model/vendorCategory");
const VendorSubCat = require("../model/vendorSubCategory");
const VendorMsgRoom = require('../model/vendorchatmessages');
const Vendor = require("../model/vendor");
const Stripe = require('stripe');
const stripe = Stripe('sk_test_jXEopk3Hf5zDe9VGjyejc8Bn');
const express = require("express");
const VendorOrder = require("../model/vendororder");
const { populate } = require("../model/vendorbankdata");
const VendorBank = require("../model/vendorbankdata");
const user = require("../model/user");
const router = express.Router();
require("dotenv").config({ path: "./config.env" });
router.get('/getgigsdata', async (req, res) => {
  try {
    const gigs = await gigsModel.find()
      .sort({ created_at: -1 })
      .limit(4)
      .populate('gigImages'); 
    res.status(200).json({ status: 'success', data: gigs, baseurl:process.env.GIGS_IMAGE });
  } catch (error) {
    // throw error;
    res.status(500).json({ status: 'error', message: 'Failed to fetch gig data' });
  }
});
router.post('/getallgigsdata', async (req, res) => {
  try{
    const { categoryIds , pricerange } = req.body;
    let gigs = [];
    if(categoryIds){
     gigs = await gigsModel.find({
      category: { $in: categoryIds},
      price: { $gte: pricerange.min, $lte: pricerange.max }

    })
    .sort({ created_at: -1 })
    .populate('gigImages');
    }else{
     gigs = await gigsModel.find()
      .sort({ created_at: -1 })
      .populate('gigImages');
    }
    res.status(200).json({ status: 'success', data: gigs, baseurl:process.env.GIGS_IMAGE });
  } catch (error) {
    throw error;
    res.status(500).json({ status: 'error', message: 'Failed to fetch gig data' });
  }
});
router.post('/getgigsdatadetail', async (req, res) => {
  try {
    const { gigId } = req.body;
    const gigs = await gigsModel.findOne({ _id: gigId })
      .populate('gigImages')
      .populate('vendorid')
      .populate('category');  
      const relatedgigs = await gigsModel.find({category:gigs.category})
      .sort({ created_at: -1 })
      .populate('gigImages');
    res.status(200).json({ status: 'success', data: gigs, relatedgigs: relatedgigs, baseurl:process.env.GIGS_IMAGE });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Failed to fetch gig data' });
  }
});
router.post('/getgigsdatabycategory', async (req, res) => {
  try {
    const { category } = req.body;
   const gigs = await gigsModel.find({ category: category })
      .populate('gigImages'); 
    res.status(200).json({ status: 'success', data: gigs });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Failed to fetch gig data' });
  }
});
router.post('/getvendorcatdata', async (req, res) => {
  try {
    const { type } = req.body;
    var cats
    if(type == "homecategory"){
     cats = await vendorcatModel.find()
     .limit(5)
  }
  else {
     cats = await vendorcatModel.find()
  }
    res.status(200).json({ status: 'success', data: cats, baseurl:process.env.GIGS_IMAGE });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Failed to fetch vendor category data' });
  }
});
router.post('/createorder', async (req, res) => {
  try {
    const { userid , gigId  , date , time , paymentMethodId , type } = req.body
    let gigs = ""
    let amount = ""
   if(type == "makeanoffer"){ 
     gigs = await gigsModel.findOne({ _id: gigId })
     .populate("vendorid")
     amount = gigs.price
   }
   else if(type == "payfromchat"){
    const chatdata = await VendorMsgRoom.findOne({ _id: gigId })
    gigs = await gigsModel.findOne({ _id: chatdata.gigId })
    .populate("vendorid")
    amount = chatdata.amount
   }
    const users = await user.findOne({ _id: userid })
    const vendororder = new VendorOrder({
      userid,
      gigId : gigs._id,
      reqdate :date,
      reqtime :time,
      username : users.userName,
      gigname : gigs.title,
      vendorname : gigs.vendorid.vendorname,
      amount  : amount,
      chatid : gigId,
      vendorid : gigs.vendorid._id
    });
    const orderdata = await vendororder.save();
if(orderdata){
  const vendorbank = await VendorBank.findOne({ vendorid: gigs.vendorid._id ,primaryaccount : true});
  console.log(vendorbank)
       const intent = await stripe.paymentIntents.create({
        amount: amount *100, // Amount in cents (e.g., 1000 = $10.00)
        currency: 'usd',
        payment_method: paymentMethodId,
        confirm: true,
        transfer_data: {
          destination: vendorbank.accountstripeid,
        },
  
      });
      const updateorderdata = await VendorOrder.findOne({ _id: orderdata._id })
      if(intent.id){
     if(updateorderdata){
      updateorderdata.stripetransactionid = intent.id
      updateorderdata.stripetransactionresponse = intent
      updateorderdata.status = 1
      await updateorderdata.save()
      return res.status(200).json({ status: 'success', message: "Payment Successfull" });
     }    
      }
            else{
        if(updateorderdata){
          updateorderdata.status = 0
          await updateorderdata.save()
          return res.status(200).json({ status: 'Error', message: "Payment Failed" });
        }
      }
    }      
      } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});
module.exports = router;
