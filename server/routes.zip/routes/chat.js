const ChatRoom = require('../model/vendorchatroom');
const ChatMessage = require('../model/vendorchatmessages');
const express = require('express');
const Vendor = require('../model/vendor');
const VendorMsgRoom = require('../model/vendorchatmessages');
const users = require('../model/user');
const router = express.Router();

// Accept the 'io' instance as a parameter
module.exports = function(io) {
  router.post('/sendmessage', async (req, res) => {
    const { userid, gigId, vendorid, content, sentby,makeanoffer,amount,date,time} = req.body;
 
    try {
      const existingMessage = await ChatRoom.findOne({
        userid,
        gigId,
        vendorid,
      });
      if (existingMessage) {
        const addnewMessage = await ChatMessage.create({
          roomid:existingMessage._id,
          message:content, 
          userid,
          vendorid,
          gigId,
          sentby,
          makeanoffer : makeanoffer,
          amount : amount,
          date : date , 
          time : time,
        });
        // Update the existing message content
        await addnewMessage.save();
        io.emit('message', addnewMessage);

      } else { 
        // Create a new message if it doesn't exist
        const newMessage = await ChatRoom.create({
          userid,
          gigId,
          vendorid,
        });

        await newMessage.save();
        const addnewroomMessage = await ChatMessage.create({
          roomid:newMessage._id,
          message:content,
          userid,
          vendorid,
          gigId,
          sentby,
          makeanoffer : makeanoffer,
          amount : amount,
          date : date , 
          time : time
        });
        await addnewroomMessage.save();

        io.emit('message', addnewroomMessage);
      }
      res.status(200).json({ message: 'Message sent successfully' });
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  router.post('/offerstatus', async (req, res) => {
    const { chatid, status} = req.body;
  
    try {
      const chatdata = await ChatMessage.findOne({ _id:chatid });
      if(chatdata){
        chatdata.makeanoffer = false
        await chatdata.save();
        const addnewMessage = await ChatMessage.create({
          roomid:chatdata.roomid,
     
          message:status == 1 ?  "Offer Accepted by Vendor of $ "+ chatdata.amount:"Offer Declined by Vendor of $ " + chatdata.amount, 
          
          userid : chatdata.userid,
          vendorid : chatdata.vendorid,
          gigId : chatdata.gigId,
          sentby : "VENDOR",
          amount : chatdata.amount,
          date : chatdata.date , 
          time : chatdata.time,
          offeraccepted : status,
          offeracceptedid : chatdata._id
         });
         await addnewMessage.save();
         io.emit('message', addnewMessage);
         res.status(200).json({ message: "Message Send Successfully"});
      }
  
  
  
    } catch (error) {
      console.error('Error sending message:', error);
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  return router;
};

router.post('/getchatsdata', async (req, res) => {
  try {
    const { userid, gigId, vendorid } = req.body;

    const existingMessage = await ChatMessage.find({
      userid,
      gigId,
      vendorid,
    });
    await ChatMessage.updateMany(
      { userid: userid,gigId: gigId,vendorid: vendorid, sentby:'VENDOR' },
      { readmessage:true }
    );
    if (existingMessage) {
      return res.json({ status: 'success',  data: existingMessage});
    }
  } catch (error) {
    console.error('Error sending message:', error);
    res.status(200).json({ error: error });
  }
});

router.get('/showallusermessage', async (req, res) => {
  try {
    const authHeader = req.headers.xauthorization;
    if (authHeader) {
    const Authtoken = authHeader.split(' ')[1];
    const vendor = await Vendor.findOne({ vendorauthtoken:Authtoken });
  if (vendor) {
    const ChatData = await ChatRoom.find({ vendorid: vendor._id })
    .populate('vendorid')
    .populate('gigId')
    .populate('userid');
    return res.json({ status: 'success',  data: ChatData});
  }else{
    res.status(200).json({ status: 'error', message: 'Token Expired' });  
  }
}
}

  catch (error) {
    console.error('Error sending message:', error);
    res.status(200).json({ error: error });
  }
});

router.post('/getchatdatabyid', async (req, res) => {
  try {
    const authHeader = req.headers.xauthorization;
    if (authHeader) {
      const Authtoken = authHeader.split(' ')[1];
      const vendor = await Vendor.findOne({ vendorauthtoken:Authtoken });
      if(vendor)
      {
    const { roomid } = req.body;
    const Chatdata = await VendorMsgRoom.find({ roomid:roomid })
    .populate('vendorid').populate('userid');
    if (roomid) {
      await VendorMsgRoom.updateMany(
        { roomid: roomid, sentby:'USER' },
        { readmessage:true }
      );
      return res.json({ status: 'success',  data: Chatdata });
    }else{
      return res.status(200).json({ status: 'error', message: 'No data found' });  
    }
  }else{
    return res.status(200).json({ status: 'error', message: 'Token Expired' });  
  } 
  }else{
    return res.status(200).json({ status: 'error', message: 'Token Expired' }); 
  }
  } catch (error) {
    console.error(error);
    return res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});

router.post('/showmessagebyuser', async (req, res) => {
  try {
   
    const { user_id } = req.body;
    const ChatData = await ChatRoom.find({ userid: user_id })
    .populate('vendorid')
    .populate('gigId')
    .populate('userid');
    return res.json({ status: 'success',  data: ChatData});
 
}
  catch (error) {
    console.error('Error sending message:', error);
    res.status(200).json({ error: error });
  }
});

router.post('/getuserchatdatabyid', async (req, res) => {
  try {
    const { roomid } = req.body;
    const Chatdata = await VendorMsgRoom.find({ roomid:roomid })
    .populate('vendorid').populate('userid');
    if (roomid) {
      await VendorMsgRoom.updateMany(
        { roomid: roomid, sentby:'USER' },
        { readmessage:true }
      );
      return res.json({ status: 'success',  data: Chatdata });
    }else{
      return res.status(200).json({ status: 'error', message: 'No data found' });  
    }

  } catch (error) {
    console.error(error);
    return res.status(200).json({ status: 'error', message: 'An error occurred' });
  }
});






